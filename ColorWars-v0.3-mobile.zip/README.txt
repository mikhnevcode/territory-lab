Color Wars v0.3. Unpack the ZIP and open index.html in Chrome. Tap the scissors on a bridge, the avatar drives there and cuts it. No internet needed.
